package com.example.myloginapp;

public class User {
    public String firstname,lastname,email,username;
    public User(){ }
    public User(String firstname,String lastname,String email,String username){
        this.firstname=firstname;
        this.lastname=lastname;
        this.email=email;
        this.username=username;
    }
}
